<?php

// define('DEBUG', true);
// define('DB_SERVER', 'localhost');
// define('DB_USER', 'root');
// define('DB_PASSWD', '1234');
// define('DB_NAME', 'pp_criando_site_com_php');

define('DEBUG', false);
define('DB_SERVER', '172.17.0.1');
define('DB_USER', 'root');
define('DB_PASSWD', 'root');
define('DB_NAME', 'c0curso');
