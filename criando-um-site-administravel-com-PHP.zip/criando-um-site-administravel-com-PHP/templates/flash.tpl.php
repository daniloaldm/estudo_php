new PNotify({
    text: '<?php echo $data['message']; ?>',
    type: '<?php echo $data['type']; ?>'
});
