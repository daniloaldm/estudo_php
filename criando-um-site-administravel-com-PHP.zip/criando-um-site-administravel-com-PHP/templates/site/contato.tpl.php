<h3>Preencha o formulário a seguir</h3>

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum vitae turpis velit. Nam suscipit ut lacus sed maximus. Nam gravida malesuada est, gravida volutpat mi aliquet quis. Nam hendrerit placerat ipsum vitae lobortis.</p>

<div class="row">
    <div class="col-1">
        <h4>Contato</h4>

        <p>R. Fulano de Tal, 999</p>
        <p>CEP 11999-000</p>
        <p>São Paulo - SP</p>
        <P><a href="phone:11988887777">(11) 98888-7777</a></P>
    </div>
    <div class="col-2">
        <form action="" method="post">
            <div class="form-group">
                <label for="">Email</label>
                <input name="from" type="email" class="form-control" placeholder="Seu email...">
            </div>
            <div class="form-group">
                <label for="">Assunto</label>
                <input name="subject" type="text" class="form-control" placeholder="Sua mensagem...">
            </div>
            <div class="form-group">
                <label for="">Mensagem</label>
                <textarea name="message" class="form-control" rows="5" placeholder="Sua mensagem"></textarea>
            </div>
            <input type="submit" value="Enviar" class="btn">
        </form>
    </div>
</div>
