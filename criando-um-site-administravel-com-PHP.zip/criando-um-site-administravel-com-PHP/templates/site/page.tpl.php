<?php 
var_dump($data);
echo $data['page']['body'];
